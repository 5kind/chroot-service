ensure_mounted /data/data/com.termux/files/usr/var/run
/data/data/com.termux/files/usr/bin/lxc-autostart